email = "vladislav+auto@myadvocate.co"  # valid email
password = ""  # This was a SECRET parameter and therefore its value is empty
